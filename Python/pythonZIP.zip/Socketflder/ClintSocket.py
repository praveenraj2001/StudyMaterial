import socket

s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)

#server address for this address we need to use ipconfig in cmd
host = "127.0.0.1"#'2409:4071:210f:63d9:f546:496c:61ff:69c8' #socket.gethostname() # "192.168.94.1" manju's IP
print(host) # this will print our local computer details which also have IP address

port = 12345
s.connect((host,port)) # Here connect is basically connect to the server at port 12345 using host


print(s.recv(1024)) # 1024bytes is allocated size for receiving data (receive the response)
s.send(b'Hello manju')
print(s.recv(1024))
print(s.recv(1024))
s.close()