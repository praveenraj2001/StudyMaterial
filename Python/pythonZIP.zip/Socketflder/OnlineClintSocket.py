import socket

s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)

host = '2405:204:5389:639a:b040:4ac6:f32c:9639' #socket.gethostname() # "192.168.94.1" manju's IP
print(host) # this will print our local computer details which also have IP address

port = 12345
s.connect((host,port)) # Here connect is basically connect to the server at port 12345 using host

print(s.recv(1024)) # 1024bytes is allocated size for receiving data (receive the response)
s.close()