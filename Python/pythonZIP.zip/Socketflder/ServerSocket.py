import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # creating socket object, AF_INET (An IPV4 related windows parameter) , SOCK_STREAM (makes protocol as TCp protocal)
# even if we don't pass parameters these 2 parameters are by default

# Socket, we use socket to send or receving data or listening for a event
# socket contains 2 things 1) IP address, 2) Port Number

# Port numbers are like doors (entry and exit points for our system)
# all https are combination of port numbers(443) and IP address
# for http port 80 is used
# total 65535 port numbers are there

host = "127.0.0.1" # this will get me my laptops IP address

print(host) # this will print our local computer details which also have IP address
port = 12345 # Random port number is selected

s.bind((host,port)) # Here passing a tuple which has host,port. and bind binds IP address and port number

s.listen(5) # Listen for request at port number 12345 (my server can handle 5 request at a time if 6th comes then it will be in queue)

while True:
    c,addr = s.accept() # accept the request name of the client and Ip address of client
    print('Received Request from',addr)
    c.send(b'Thank you for Connecting') # here b is byte information
    c.close()