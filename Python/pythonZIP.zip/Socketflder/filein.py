fd = open("nwefile.txt","r")
k = fd.readline()
fd.close()
print(k)