# OSI model
* open system interconnection
# networking concepts
* TCP/IP basics
* TCP header & contents
* UDP header & contents
* IP header & contents
* IP address 


# SUMMARY
## TCP
* Full Duplex
* Connection Oriented
* For forming connection we have a method called __3-Way handshake__
    * SYN segment
    * SYN + ACK segment
    * ACK segment

* Wait time --> If acknowledgement is not received client will wait for sometime
* We have header data at top for a packet