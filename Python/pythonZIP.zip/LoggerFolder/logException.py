import logging
# Create and configure logger
logging.basicConfig(filename="newfileExcep.log",format='%(asctime)s %(message)s',filemode='w')

# Creating an object
logger = logging.getLogger()

# Setting the threshold of logger to DEBUG
logger.setLevel(logging.DEBUG) # (Here we set the type of logging) (change this type to see the change in newfile.log)

a,b = 5,0

try:
    c = a/b
except Exception as e:
    logger.exception("Exception occured")