import logging # stop naming file names as logging (because they are already existing in system)

# Create and configure logger
logging.basicConfig(filename="newfile.log",format='%(asctime)s %(message)s',filemode='w')

# Creating an object
logger = logging.getLogger()

# Setting the threshold of logger to DEBUG
logger.setLevel(logging.DEBUG) # (Here we set the type of logging) (change this type to see the change in newfile.log)

# Test message (5 Levels of logging)
logger.debug("Harmless debug Message") # it will log minutest(smallest) info (low priority)
logger.info("Just an information") # it will a bit higher level information than debug is recorded
logger.warning("Its a Warning") # this might create a failure in future that kind of info will be recorded
logger.error("Did you try to divide by zero") # Exceptions will be logged
logger.critical("Internet is down") # Critical messages will be logged (Highest priority)

# if debug is set then all are recorded
# if info is set then all are recorded except debug
# if error is set then error and critical will get recorded -> debug, info, warning will not be recorded