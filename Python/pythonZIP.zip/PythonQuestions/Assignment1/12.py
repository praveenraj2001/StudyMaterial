# Program for Digital root of a given number
def DigitalRoot(num):
    if(num < 10):
        return num
    num=num%10+DigitalRoot(num//10)
    return DigitalRoot(num)

num= int(input("Enter the number\n"))
print((DigitalRoot(num)))