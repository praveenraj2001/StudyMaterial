# Program to Check if given character is vowel or consonant
vowels = {'a','e','i','o','u'}

my_char = input("Please enter a Character\n")

if my_char.lower() in vowels:
    print("It is Vowel")
else:
    print("It is Consonant")