# Program for Types of Triangles
print("Input lengths of the Triangle sides: ")
x = int(input("x: "))
y = int(input("y: "))
z = int(input("z: "))
angle = int(input("enter angle if any angle is 90 else enter 0\n"))

if x == y == z:
	print("Equilateral Triangle")
elif x==y or y==z or z==x:
	print("isosceles Triangle")
elif angle == 90:
    print("Right angle Triangle")
else:
	print("Scalene Triangle")
