# Program for Maximum number by deleting single digit in a 4 digit number
def maxnumber(n):     
    ans = 0
    i = 1

    while n // i > 0:
        temp = (n//(i * 10))*i + (n % i)
        i *= 10
        if temp > ans:
            ans = temp
    n = ans       
    return ans
   
  
n = 5872
print(maxnumber(n))