# Program for Quadrant of given point (x,y)
x, y = map(int, list(input("Type variable X and Y : ").split(" ")))


if x > 0 and y > 0: print(f"point ({x}, {y}) lies in the First quadrant")

elif x < 0 and y > 0: print(f"point ({x}, {y}) lies in the Second quadrant")

elif x < 0 and y < 0: print(f"point ({x}, {y}) lies in the Third quadrant") 

elif x > 0 and y < 0: print(f"point ({x}, {y}) lies in the Fourth quadrant")