# Program For Fibonacci and Tri
fibonacciList = []
tribonacciList = []

# Start of Fibonacci
def fibonacci(number_of_terms):
   cnt = 0

   num1 = 0
   num2 = 1
   temp = 0
 
   while cnt <= number_of_terms:
      fibonacciList.append(num1)
      temp = num1 + num2
      num1 = num2
      num2 = temp
      cnt = cnt + 1
# End of Fibonacci
# Start of Tribonacci
def Tribonacci(num) :
	if (num == 0 or num == 1 or num == 2) :
		return 0
	elif (num == 3) :
		return 1
	else :
		return (Tribonacci(num - 1) +
				Tribonacci(num - 2) +
				Tribonacci(num - 3))
		

def printTrib(num) :
	for i in range(1, num) :
		tribonacciList.append(Tribonacci(i))
# End of Tribonacci

number = int(input("Please Enter the number\num"))
fibonacci(number)
print(fibonacciList)

printTrib(number)
print(tribonacciList)
