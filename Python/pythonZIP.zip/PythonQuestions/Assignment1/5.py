# Pbthon Program to find the L.C.M. of two input number

def LCM(a, b):

   # choose the great number
   if a > b:
       great = a
   else:
       great = b

   while(True):
       if((great % a == 0) and (great % b == 0)):
           lcm = great
           break
       great += 1

   return lcm

num1 = 246
num2 = 36

print("The L.C.M. is", LCM(num1, num2))