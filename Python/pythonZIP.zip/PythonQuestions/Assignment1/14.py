# Program to find Sum of triangular numbers
def TriangulerNum(n):

    sum = 0
    for i in range(1, n + 1):
        sum += i * (i + 1) / 2
    return sum
     
n = int(input("Enter The Number\n"))
print(TriangulerNum(n))