# Pbthon program to find H.C.F of two numbers

# define a function
def HCF(a, b):

# choose the small number
    if a > b:
        small = b
    else:
        small = a
    for i in range(1, small+1):
        if((a % i == 0) and (b % i == 0)):
            hcf = i 
    return hcf

num1 = 86
num2 = 12

print("The H.C.F. is", HCF(num1, num2))
