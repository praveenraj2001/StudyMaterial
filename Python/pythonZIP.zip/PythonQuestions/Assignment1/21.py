# Program for finding Sum of factors
def SumOfFactors(num):
    SumOfFactors = [1]
    for i in range(2,num+1):
        if num%i==0:
            SumOfFactors.append(i)
    return sum(SumOfFactors)-num

num=int(input("Please enter the number\n"))
print(SumOfFactors(num))