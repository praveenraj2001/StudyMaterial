# Program for Triangle and Pascal Triangle
import math
rows = int(input('Enter the number of rows\n'))

for i in range(rows+1):
    for j in range(i):
        print(i, end=" ")
    print("")

print(" ")

for i in range(rows):
    for j in range(rows-i+1):
        print(end=" ")
    for j in range(i+1):
         print(math.factorial(i)//(math.factorial(j)*math.factorial(i-j)), end=" ")
    
    print()