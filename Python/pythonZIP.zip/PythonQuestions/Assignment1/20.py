# Program to find factorial of a number
import math

number = int(input("Please enter a number\n"))

print(f"Factorial of the number {number} is {math.factorial(number)}\n")