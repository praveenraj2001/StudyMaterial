# Python Program to Reverse and sum a Number using While loop    
     
Number = int(input("\nPlease Enter any Number: "))  
n = Number  
Reverse = 0    
sum = 0
while(Number > 0):    
    Reminder = Number %10    
    Reverse = (Reverse *10) + Reminder    
    Number = Number //10    

while (n != 0):
    sum += (n % 10)
    n = n//10
     
print(f"Reverse and sum of entered number is = {Reverse}, {sum}\n") 
