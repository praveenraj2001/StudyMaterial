# Program for Super Prime numbers
def SieveOfEratosthenes(n, tempPrime):
    tempPrime[0] = tempPrime[1] = False
    for i in range(2,n+1):
        tempPrime[i] = True
  
    for multiP in range(2,n+1):
        if (multiP*multiP<=n and tempPrime[multiP] == True):
            for i in range(multiP*2,n+1,multiP):
                tempPrime[i] = False
                multiP += 1
def superPrimes(n):

    tempPrime = [1 for i in range(n+1)]
    SieveOfEratosthenes(n, tempPrime)
  
    primes = [0 for i in range(2,n+1)]
    j = 0
    for multiP in range(2,n+1):
       if (tempPrime[multiP]):
           primes[j] = multiP
           j += 1
  
    for k in range(j):
        if (tempPrime[k+1]):
            print (primes[k],end=" ")
 
n = 500
print ("\nSuper-Primes are :")
superPrimes(n)