# Program for No.of combinations for n teams to play each other i.e. nCr
import math

n = int(input("Enter no. of teams \n"))

answer = math.factorial(n)//(math.factorial(n-2)*math.factorial(2))

print("No.of combinations for n teams to play each other is ", answer)