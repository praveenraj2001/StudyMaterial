# Program to Find the missing number , given the original and modified
String = input('Enter elements of Original list\n')

StringToList = String.split()
for i in range(len(StringToList)):
    StringToList[i] = int(StringToList[i])
input_string1 = input('Enter elements of Modified list\n')

StringToList1 = input_string1.split()
for i in range(len(StringToList1)):
    StringToList1[i] = int(StringToList1[i]) 
print("Missing values in Modified list compared to Original list:", (set(StringToList).difference(StringToList1)))