# Program for odd element out
def StrayNum(StrToList):
    strays = StrToList[0]
    for i in range(len(StrToList)):
        if(strays != StrToList[i]):
            return StrToList[i]
    return 0

input_string = input('Enter elements of a list\n')

StrToList = input_string.split()
for i in range(len(StrToList)):
    StrToList[i] = int(StrToList[i])
x=StrayNum(StrToList)
if x!=0:
    print(x)