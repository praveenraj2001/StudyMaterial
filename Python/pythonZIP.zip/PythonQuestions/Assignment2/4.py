#Program to find no.of people in a bus, given the data of people onboarding and alighting at each station
String = input('Enter elements of a list of Onboarding\n')

StringToList = String.split()
for i in range(len(StringToList)):
    StringToList[i] = int(StringToList[i])
input_string1 = input('Enter elements of a list of alighting\n')

StringToList1 = input_string1.split()
for i in range(len(StringToList1)):
    StringToList1[i] = int(StringToList1[i]) 
print(sum(StringToList)-sum(StringToList1))