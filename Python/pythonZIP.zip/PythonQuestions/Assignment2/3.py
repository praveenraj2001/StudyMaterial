# Program for Average speed of vehicle given distance travelled for fixed time intervals
listTime = []
listTime = input("Enter the speeds for constant intervals\n").split(" ")

for i in range(0, len(listTime)):
    listTime[i] = float(listTime[i])


print((sum(listTime)/len(listTime)))