# Program to Find the difference between two lowest numbers in list
listitems = []
listitems = input("Enter a list values\n").split(" ")

for i in range(0, len(listitems)):
    listitems[i] = float(listitems[i])

listitems.sort()
print(listitems[0]-listitems[1])