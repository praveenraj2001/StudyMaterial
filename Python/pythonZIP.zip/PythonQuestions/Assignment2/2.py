# Program for finding the element which is close to its mean
import math
string = input()

StringToList = string.split()
for i in range(len(StringToList)):
    StringToList[i] = int(StringToList[i])
sum=0
for i in StringToList:
    sum=sum+i
m=sum/len(StringToList)

print(min((StringToList), key=lambda x:abs(x-m)))




