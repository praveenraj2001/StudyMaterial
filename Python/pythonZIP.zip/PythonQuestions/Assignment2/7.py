# Program to cnt no.of elements smaller then theri mean
String = input('Enter elements of a list\n')

StringToList = String.split()
for i in range(len(StringToList)):
    StringToList[i] = int(StringToList[i])
sum,cnt=0,0
for i in StringToList:
    sum=sum+i
avge=sum/len(StringToList)
for i in StringToList:
    if i<avge:
        cnt=cnt+1
print(cnt)