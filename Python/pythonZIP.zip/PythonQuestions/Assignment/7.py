def maximum(number):
    cnt = [0 for x in range(10)]
    string = str(number)
    for i in range(len(string)):
        cnt[int(string[i])] = cnt[int(string[i])] +  1
    result = 0
    multiplier = 1
    for i in range(10):
        while cnt[i] > 0:
            result = result + ( i * multiplier )
            cnt[i] = cnt[i] - 1
            multiplier = multiplier * 10
    return result
number = input()
print(maximum(number))