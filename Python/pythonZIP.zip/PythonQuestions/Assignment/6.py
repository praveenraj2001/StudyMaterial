def maxnumber(number, klen):
    for i in range(0, klen):
        ans = 0
        i = 1
        while number // i > 0:
            temporary = (number//(i * 10))*i + (number % i)
            i *= 10
            if temporary > ans:
                ans = temporary
        n = ans       
    return ans
number = int(input())
klen = 1
print(maxnumber(number, klen))