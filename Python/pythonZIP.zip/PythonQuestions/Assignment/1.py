import string

timestr = str(input("Please enter date\n"))
a = list()
a = timestr.split(":")
a[0] = int(a[0])
a[1] = int(a[1])
a[2] = int(a[2])

def listToString(s): 
    str1 = ""   
    for ele in s: 
        str1 = str1 +  ele + ":"
    str1 = str1.strip(":")
    return str1


a[2] = int(a[2])
print(a)
if (a[2]>=60):
    rem = a[2]//60
    a[2] -= 60*rem
    a[1] += rem

if (a[1]>=60):
    rem = a[1]//60
    a[1] -= 60*rem
    a[0] += rem

a[0] = str(a[0])
a[1] = str(a[1])
a[2] = str(a[2])

finalstr = listToString(a)
print (finalstr)
