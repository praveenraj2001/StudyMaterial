def rgb_to_hex(rgb):
    return '#%02x%02x%02x' % rgb

noice = input('Enter HEX value: ').lstrip('#') # hex
noice2 = input('Enter RGB value: ')    # RGB
res = tuple(map(int, noice2.split(',')))

print('RGB value =', tuple(int(noice[i:i+2], 16) for i in (0, 2, 4)))

print(rgb_to_hex(res))