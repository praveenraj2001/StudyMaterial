def listToString(s): 
    str1 = ""   
    for ele in s: 
        str1 = str1 +  ele + "-"
    str1 = str1.strip("-")
    return str1

list1 = []
str1 = ' abcd'
length = len(str1)
for i in range(1,length):
    c = (str1[i])*i
    list1.append(c.title())

print(listToString(list1))