
import string

timestr = str(input("Please enter date\n"))
a = list()
a = timestr.split("/")
a[0] = int(a[0])
a[1] = int(a[1])
a[2] = int(a[2])

def listToString(s): 
    str1 = ""   
    for ele in s: 
        str1 = str1 +  ele + "/"
    str1 = str1.strip("/")
    return str1


a[2] = int(a[2])
print(a)

if((a[1]==1)|(a[1]==3)|(a[1]==5)|(a[1]==7)|(a[1]==8)|(a[1]==10)|(a[1]==12)):
    if (a[0]>=32):
        rem = a[0]//32
        a[0] -= 31*rem
        a[1] += rem


elif((a[1]==4)|(a[1]==6)|(a[1]==9)|(a[1]==11)):
    if (a[0]>=31):
        rem = a[0]//31
        a[0] -= 30*rem
        a[1] += rem


elif((a[1]==2)):
    if (a[0]>=29):
        rem = a[0]//29
        a[0] -= 28*rem
        a[1] += rem


a[0] = str(a[0])
a[1] = str(a[1])
a[2] = str(a[2])

finalstr = listToString(a)
print (finalstr)
