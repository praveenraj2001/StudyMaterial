# Program for Integer to IP and IP to integer

import ipaddress
inttoIP=int(input("Enter Integer to convert into ip address:"))
print(ipaddress.ip_address(inttoIP))
IpToInt=input("Enter ip address to convert into integer:")
print(int(ipaddress.ip_address(IpToInt)))