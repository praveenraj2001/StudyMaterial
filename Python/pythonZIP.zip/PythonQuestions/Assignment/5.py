str_=input()
mex_list=[]
for i, val in enumerate(str_[:]):
    up=str_[i].upper()
    c=str_[:i] + up + str_[i+1:]
    mex_list.append(c)
print(mex_list)
