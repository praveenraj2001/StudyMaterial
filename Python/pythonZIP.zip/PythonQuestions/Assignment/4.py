def isogram(str_):
    str_ = str_.lower()
    for char in str_:
        if str_.count(char) > 1:
            return False
    return True

print(isogram(input()))