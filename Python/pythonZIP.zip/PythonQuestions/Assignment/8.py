def frequency(str):
    strToList = str.split()
    ListToSet_unique = set(strToList)      
    for words in ListToSet_unique :
        print('Frequency', words , 'is :', strToList.count(words))
  
    
string = input("Enter the Text\n")
frequency(string)