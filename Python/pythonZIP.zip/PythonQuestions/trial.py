name = "ansari"

age = 100

print("my name is ", name, " my age is ", age, end="\n\n\n\n") 
print("my name is ", name, " my age is ", age, sep="---")
print(f"my name is {name} and age is {age}")

print("my name is {} and age is {}" . format(name, age))
print("my name is {1} and age is {0}" . format(name, age))
print("my name is %s and age is %d" %(name,age))