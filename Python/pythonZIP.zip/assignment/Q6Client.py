import socket
import sys
import json

jsonobj1 = {"PSNO":"123456","Location":"Mysore"}
jsonobj2 = {"PSNO":"654321","Location":"Bamglore"}
jsonobj3 = {"PSNO":"987456","Location":"Chennai"}

# converting jsonobj1,2,3 Dictionary into jsonobj1,2,3 (json) object
jsonobj1 = json.dumps(jsonobj1).encode('utf-8') 
jsonobj2 = json.dumps(jsonobj2).encode('utf-8')
jsonobj3 = json.dumps(jsonobj3).encode('utf-8')

listobjs = [1:jsonobj1,2:jsonobj2,3:jsonobj3]
listobjs = json.dumps(listobjs).encode('utf-8')

try:
    sock = socket.socket()
except socket.error as err:
    print("Socket error because of %s" %(err))
    
port = 12345
address = socket.gethostname() 

try:
    sock.connect((address,port))
    sock.send((listobjs))
except socket.gaierror:
    print("There an error resolving the host")
    sys.exit()
    
print(listobjs,"Was sent! ")
updatedJson = sock.recv(1024)
print("This is the updated json --> ",updatedJson.decode())
sock.close()