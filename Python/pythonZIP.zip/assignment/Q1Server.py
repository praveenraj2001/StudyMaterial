import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # creating socket object, AF_INET (An IPV4 related windows parameter) , SOCK_STREAM (makes protocol as TCp protocal)

host = socket.gethostname() # this will get me my laptops IP address

print(host) # this will print our local computer details which also have IP address
port = 12345 # Random port number is selected

s.bind((host,port)) # Here passing a tuple which has host,port. and bind binds IP address and port number

s.listen(5) # Listen for request at port number 12345 (my server can handle 5 request at a time if 6th comes then it will be in queue)

while True:
    c,addr = s.accept() # accept the request name of the client and Ip address of client
    print('Received Request from',addr)
    k = c.recv(1024).decode()
    print(k)
    c.send((k[::-1]).encode()) # here b is byte information
    #c.close()
    