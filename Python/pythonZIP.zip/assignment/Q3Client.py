import socket
import time
c = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)

host = "2405:204:5389:639a:b040:4ac6:f32c:9639" #socket.gethostname() 

print(host)
port = 12345 
addr = (host,port)

seconds =  time.time()
data = time.ctime(seconds)

data = data.encode()
c.sendto(data,addr)

print(f"sending to Client : {data}")