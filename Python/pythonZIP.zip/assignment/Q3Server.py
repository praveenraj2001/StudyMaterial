import socket

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 

host = socket.gethostname() 

print(host)
port = 12345 

s.bind((host,port))
# no listening in UDP

data,addr = s.recvfrom(1024)
data = data.decode()

print(f"Data from Client : {data}")