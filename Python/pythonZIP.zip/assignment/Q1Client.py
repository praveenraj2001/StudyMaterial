import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

host = socket.gethostname() #socket.gethostname() # "192.168.94.1" manju's IP
print(host) # this will print our local computer details which also have IP address

port = 12345
s.connect((host,port))
 # Here connect is basically connect to the server at port 12345 using host
k=0
while True:
    strg = input("Please enter string cquit,squit  ")
    s.send(strg.encode())
    print("Reversed string is --> ",end="")
    print(s.recv(1024).decode())
    #s.close()