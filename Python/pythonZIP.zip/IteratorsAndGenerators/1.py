# hell = "nice one"
# print(hell[0])
# for i in hell:
#     print(i,end="")
    
kal = {1,2,3,"hello"}
for i in kal:
    print(i)