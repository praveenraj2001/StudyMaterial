mytuple = ("apple","banana","cherry")
myit = iter(mytuple)
print(type(myit))

print(next(myit))
print(next(myit))
print(next(myit))

myset = {"apple","banana","cherry"}
myit = iter(myset)
print(type(myit))

print(next(myit))
print(next(myit))
print(next(myit))

mylist = ["apple","banana","cherry"]
myit = iter(mylist)
print(type(myit))

print(next(myit))
print(next(myit))
print(next(myit))

mystr = "apple"
myit = iter(mystr)
print(type(myit))

print(next(myit),end = "")
print(next(myit),end = "")
print(next(myit),end = "")
print(next(myit),end = "")
print(next(myit),end = "")


mydict = {1:"apple",2:"banana",3:"cherry"}
myit = iter(mydict)
print(type(myit))

print(next(myit))
print(next(myit))
print(next(myit))
