# class MyNumbers: # self is reference to current objects
#     def __iter__(self):
#         self.a = -5
#         return self # returning an object
#     def __next__(self):
#         x = self.a
#         self.a +=2
#         return x
    
# myclass = MyNumbers()
# myiter = iter(myclass) # changing the iter and next definations here

# print(next(myiter))
# print(next(myiter))
# print(next(myiter))
# print(next(myiter))
# print(next(myiter))
# print(next(myiter))


# # Interating through 
# class MyNumbers: # self is reference to current objects
#     def __init__(self,mylist):
#         self.mylist = mylist
#     def __iter__(self):
#         self.a = 0
#         return self # returning an object
#     def __next__(self):
#         x = self.a
#         self.a +=1
#         return self.mylist[x]

# mylist = ["apple","banana","cherry"]
# myclass = MyNumbers(mylist)
# myiter = iter(myclass) # changing the iter and next definations here

# print(next(myiter))
# print(next(myiter))
# print(next(myiter))


# class MyNumbers: # self is reference to current objects
#     def __iter__(self):
#         self.a = -5
#         return self # returning an object
#     def __next__(self): # we cannot change the no of parameters
#         x = self.a
#         self.a +=2
#         return x
    
# myclass = MyNumbers()
# myiter = iter(myclass) # changing the iter and next definations here
# for x in myiter:
#     print(x) #here the iteration is not stopping
    
    
    
    
#solution for the above problem

class MyNumbers: # self is reference to current objects
    def __iter__(self):
        self.a = 2
        return self # returning an object
    def __next__(self):
        if self.a<=100:
            flag = 0
            for x in range(2,(self.a//2 +1)):
                if(self.a%x==0):
                    flag+=1
            if flag>0:
                self.a +=1
                return [self.a-1,"Not Prime"]
            else:
                self.a +=1
                return [self.a-1,"Prime"]
        else:
            raise StopIteration
    
myclass = MyNumbers()
print(myclass)
myiter = iter(myclass) # changing the iter and next definations here
for x in myiter:
    print(x) #here the iteration is not stopping