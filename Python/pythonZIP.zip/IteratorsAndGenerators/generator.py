def simpleGeneratorFun():
    yield 1
    yield 2
    yield 3

# for value in simpleGeneratorFun():
#     print(value)
    
x = simpleGeneratorFun()


# print(x.__next__())
# print(x.__next__())
# print(x.__next__())

#or 
print(x)
print(next(x))
print(next(x))
print(next(x))


def table(n):
    for i in range(1,11):
        yield n*i
        # i +=1

for i in table(15):
    print(i)