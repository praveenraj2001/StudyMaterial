mytuple = ("apple","banana","cherry")
for x in mytuple:
    print(x)

mydict = {1:"apple",2:"banana",3:"cherry"}
for key,value in mydict.items():
    print(key,value)