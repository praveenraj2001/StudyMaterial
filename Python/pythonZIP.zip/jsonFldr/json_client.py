import socket
import sys
import json

jsonResult = {"PSNO":"123456","Location":"Mysore"}
jsonResult = json.dumps(jsonResult).encode('utf-8') # converting jsonResult Dictionary into jsonResult (json) object

try:
    sock = socket.socket()
except socket.error as err:
    print("Socket error because of %s" %(err))
    
port = 12345
address = socket.gethostname() 

try:
    sock.connect((address,port))
    sock.send(jsonResult)
except socket.gaierror:
    print("There an error resolving the host")
    sys.exit()
    
print(jsonResult,"Was sent! ")
updatedJson = sock.recv(1024)
print("This is the updated json --> ",updatedJson.decode())
sock.close()