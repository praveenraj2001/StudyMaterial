import socket
import json

s = socket.socket()# default -> socket.AF_INET, socket.SOCK_STREAM
host = socket.gethostname()
print(host)
port = 12345
s.bind((host,port))
s.listen(5)
while True:
    c,addr = s.accept() # accept the request name of the client and Ip address and port no of client
    print('Received Request from',addr)
    jsonReceived = c.recv(1024)
    print("Json Received --> ", jsonReceived.decode())
    #print(type(jsonReceived))
    jsonReceived = jsonReceived.decode()
    #print(type(jsonReceived))
    jsonReceived = json.loads(jsonReceived)
    jsonReceived.update({"Name":"Praveenraj"})
    jsonReceived = json.dumps(jsonReceived).encode('utf-8')
    c.send(jsonReceived)
    c.close()
    