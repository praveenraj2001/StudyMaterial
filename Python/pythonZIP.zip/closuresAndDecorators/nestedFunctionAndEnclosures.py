# def outer(name):
#     def inner():
#         print(name)
#     inner()
    
# outer("Hello world")


# Accessing inner function through main 
def outer(name):
    def inner(k): # This is a closure
        print(name,k)
    return inner
# call the enclosing function
myfunc = outer("hello world") # here myfunc is function object
print(myfunc)
print(type(myfunc))
myfunc(1) # here once function is returned the variables should be destroyed but we can access inner here thats because it's a closure(enclosed function)
myfunc("hey")
myfunc('astalavista')
