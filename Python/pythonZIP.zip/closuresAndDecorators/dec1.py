def hello_decorator(func):# here hello_decorator is decorator 
    # inner1 is a wrapper function in 
    # which the arguments is called 
    # func()
    def inner1(a,b):
        
        print("Hello, this is before function execution")
        
        func(a,b)
        print("this is after function execution")        
    return inner1

def func_to_be_used():
    print("This is inside the function!")
    
@hello_decorator # this will take care of add = hello_decorator(add(a,b))
def add(a,b):
    print(a+b)
#func_to_be_used()
#func_to_be_used = hello_decorator(func_to_be_used) # this is decorating this func_to_be_used

add(1,5)