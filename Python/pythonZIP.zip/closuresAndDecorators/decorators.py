def hello_decorator(func):
    # inner1 is a wrapper function in
    # which the arguments is called
    func()
    def inner1():
        print("Hello, this is before function execution")
        
        func()
        print("this is after function execution")
        
    return inner1

def func_to_be_used():
    print("This is inside the function!")
    
#func_to_be_used()
func_to_be_used = hello_decorator(func_to_be_used) # this is decorating this func_to_be_used

func_to_be_used()
print("..")
func_to_be_used()