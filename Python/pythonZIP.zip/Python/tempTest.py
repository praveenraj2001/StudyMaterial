from fileinput import filename
import os
filename = "History_record.txt"
def updateData(filename,id,information):
    fh_r=open(filename, "r")
    fh_w=open("temp.txt", "w")
    s=' '
    cnt = False
    while(s):
        s=fh_r.readline()
        L=s.split("-")
        if len(s)>0:
            if int(L[0])==id:
                fh_w.write(L[0]+"-"+L[1]+"-"+L[2]+"-"+information+"\n")
                cnt = True
            else:
                fh_w.write(s)
    if(cnt==False):
        fh_w.close()
        fh_r.close()
        os.remove(filename)
        os.rename("temp.txt",filename)
        return -1
    else:   
        fh_w.close()
        fh_r.close()
        os.remove(filename)
        os.rename("temp.txt",filename)
        return 0
       
print(updateData(filename,0,"this is old test test"))