
import os
class clsUpdate():
    def updateData(self, filename, id, information):
        fh_r = open(filename, "r")
        fh_w = open("temp.txt", "w")
        s = ' '
        cnt = False
        while(s):
            s = fh_r.readline()
            L = s.split("-")
            if len(s) > 0:
                if int(L[0]) == id:
                    fh_w.write(L[0]+"-"+L[1]+"-"+L[2]+"-"+information+"\n")
                    cnt = True
                else:
                    fh_w.write(s)
        if(cnt == False):
            fh_w.close()
            fh_r.close()
            os.remove(filename)
            os.rename("temp.txt", filename)
            return -1
        else:
            fh_w.close()
            fh_r.close()
            os.remove(filename)
            os.rename("temp.txt", filename)
            return 0

class clsDelete():
    def deleteData(filename,id):
        fh_r=open(filename, "r")
        fh_w=open("temp.txt", "w")
        s=' '
        while(s):
            s=fh_r.readline()
            L=s.split("-")
            if len(s)>0:
                if int(L[0])==id:
                    fh_w.write("")
                else:
                    fh_w.write(s)
        fh_w.close()
        fh_r.close()
        os.remove(filename)
        os.rename("temp.txt",filename)


class clsInsert():
    def insertData(filename,id):

        fh_r=open(filename, "r")
        fh_w=open("temp.txt", "w")
        s=' '
        cnt = True
        while(s):
            s=fh_r.readline()
            L=s.split("-")
            if len(s)>0:
                fh_w.write(L[0]+"-"+L[1]+"-"+L[2]+"-"+L[3])
                if int(L[0])==id:
                    print("ID already existing please change the ID")
                    cnt = False
        if(cnt):    
                    name_type = input("Please Enter Type of entry ")
                    name = input("Please enter name of entry ")
                    information = input("Please Enter information of entry ")
                    fh_w.write(str(id)+"-"+name_type+"-"+name+"-"+information+"\n")
                    fh_w.close()
                    fh_r.close()
                    os.remove(filename)
                    os.rename("temp.txt",filename)
                        
        fh_w.close()
        fh_r.close()
        os.remove("temp.txt")

# class Admin(clsUpdate,clsDelete,clsInsert):
#     password = 
    
    
#deleteData("History_record.txt",3)
# insertData("History_record.txt",2,"Pre Historic animal","Dianosour","noice information")
#insertData("History_record.txt",3)

userChoice = input("Please select The mode ADMIN / TOURIST ")
if(userChoice.lower()=="admin"):
    print("admin is chosen")
    psw = input("Please enter Password to access ADMIN MODE ")
elif(userChoice.lower()=="tourist"):
    print("tourist is chosen")