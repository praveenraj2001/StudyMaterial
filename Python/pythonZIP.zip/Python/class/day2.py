# from time import process_time




# class Tiger():
#     legs = 4
#     def tiger_roars(self):
#         print ("Tiger roars")
#     # here self is this method belongs to the class Tiger
#         print("self address is ->",id(self))
# obj = Tiger()

# print("object address is ->",id(obj)) # memory location of the object

# print(obj.legs)
# obj.tiger_roars()




# class Tiger():
#     legs = 4 # class variables
#     def tiger_roars(self):  # instance method
#         self.legs = 5       # instance Variable
#         print ("Tiger roars")
#         print("tiger legs are",self.legs)
# obj = Tiger()

# print("object address is ->",id(obj)) # memory location of the object

# print(Tiger.legs)
# obj.tiger_roars()
# print(Tiger.legs) 
# # instance variable can't change class variable




# class Tiger():
#     legs = 4 # class variables
    
#     @staticmethod # static method can also be created without obj but it cannot modify the class variables
#     def my_static_method(self):
#         print("static method")
    
#     @classmethod # this defines that this my_class_methods is not instance method but it's class method
#     def my_class_method(cls,mylegs):
#         cls.legs = mylegs
           
#     def tiger_roars(self):  # instance method
#         self.legs = 5       # instance Variable
#         print ("Tiger roars")
#         print("tiger legs are",self.legs)
# obj = Tiger()

# print("object address is ->",id(obj)) # memory location of the object

# print(Tiger.legs)
# obj.tiger_roars()
# print(Tiger.legs) 

# Tiger.my_class_method(10)

# print(Tiger.legs) 




# ## Constructor (it is used to initilize the data )
# class Tiger():
#     name = ""
#     psnumb = None 
#     phonenum = None
#     city = ""
#     country = ""
      
#     @classmethod # this is if we want to update class variables  
#     def __init__(self,myname,psnumb): # constructor overloading is not possible but however if it is defined then the last defined constructor will be taken into account
#        self.name = myname
#        self.psnumb = psnumb
#        print(f"student name = {self.name} and ps number is {self.psnumb}")
       
#     def set_data(self,city,country): # constructor overloading is not possible but however if it is defined then the last defined constructor will be taken into account
#        self.city = city
#        self.country = country
#        print(f"my country = {self.country} and my country = {self.city}")

# obj = Tiger("Praveenraj",99871)
# obj.set_data("INDIA","Telangana")
# print(Tiger.psnumb)



# class car():
#     modelNumber = None
#     carName = ""
#     mfgDate = ""
#     price = None
    
#     def __init__(self,mfgDate,price): # constructor overloading is not possible but however if it is defined then the last defined constructor will be taken into account
#       self.mfgDate = mfgDate
#       self.price = price
#       print(f"car mfg date = {self.mfgDate} and car price = {self.price}")
      
#     def set_data(self,modelNumber,carName): # constructor overloading is not possible but however if it is defined then the last defined constructor will be taken into account
#        self.modelNumber = modelNumber
#        self.carName = carName
#        print(f"carname = {self.carName} and car model number = {self.modelNumber}")
       
# obj = car("01/01/2000",450000)

# val = input("enter the car name ")
# val1 = int(input("enter the car model number "))

# obj.set_data(val1,val)




# inheretence
class animal():
    animalLegs = 4
    def animalSound(self):
        print("animal makes Sound")
class Tiger(animal):
    legs = 4
    def tigerRoar(self):
        print("tiger roar")
        
class Cub(Tiger):
    cublegs = 4
    def cubRoar(self):
        print("Cub Roars")
        
cub = Cub()
cub.cubRoar()
cub.tigerRoar()
cub.animalSound()






# # inheretence
# class animal():
#     animalLegs = 4
#     def animalSound(self):
#         print("animal makes Sound")
# class Tiger:
#     legs = 4
#     def tigerRoar(self):
#         print("tiger roar")
        
# class Lion:
#     lion_legs = 4
#     def lionRoar(self):
#         print("lion roar")
        
# class Cub(Tiger,Lion):
#     cublegs = 4
#     def cubRoar(self):
#         print("Cub Roars")
        
# cub = Cub()
# cub.cubRoar()
# cub.tigerRoar()
# #cub.animalSound()


