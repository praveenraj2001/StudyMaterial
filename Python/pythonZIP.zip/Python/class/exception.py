# try:
#     a,b = 10,0

#     res = a/b
# except:
#     print("problem with input")


# try:
#     a,b = 10,0

#     res = a/b
# except Exception as e: # here Execption is generic exception
#     print("problem with input --> ",e)
    
# except ZeroDivisionError as ze:
#     print("zerodivision error --> ",ze)
    
# else:
#     print("There is no error ")

# finally:# weather there is error or not this block will get executes
#     print("Finally block executes")
   
   
    

# try:
#     a,b = 10,0

#     try:
#         r = a/"xyz"
#     except Exception as l:
#         print(l)
#     res = a/b    
# except Exception as e: # here Execption is generic exception
#     print("problem with input --> ",e)
    
# except ZeroDivisionError as ze:
#     print("zerodivision error --> ",ze)
    
# else:
#     print("There is no error ")

# finally:# weather there is error or not this block will get executes
#     print("Finally block executes")
    
    
    
# Throw our own exception with help of system exception

# age = int(input("Enter the age "))
# try:
#     if age <18:
#       raise ArithmeticError ("You are not eligible to vote")
# except ArithmeticError as ae:
#     print("Error is ",ae)


# throw our own exception


class hot_weather_exception(Exception):
    def __init__(self,message):
        super().__init__(message)
        
class cold_weather_exception(Exception):
    def __init__(self,message):
        super().__init__(message)
        
        
class Weather():
    def __init__(self,temp):
        self.temp = temp
        
    def check_temp(self):
        if self.temp<15:
            raise cold_weather_exception("Cold Outside {}".format(self.temp))
        elif self.temp>30:
            raise hot_weather_exception("Hot Outisde {}".format(self.temp))
        else:
            print("pleasent temp")
            
temp = int(input("enter temprature "))

weather = Weather(temp)
weather.check_temp()

