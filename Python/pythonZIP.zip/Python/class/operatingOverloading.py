a,b = 10,20
print(a+b)

a = "hello "
b = "world "
print(a+b)