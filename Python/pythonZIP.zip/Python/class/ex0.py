# def listfun():
#     hey = [1,2,3,"bear",4]
#     return hey

# bye = listfun()
# print(bye)



# def my_fun(*kwargs):
#     for i in kwargs:
#         print(i)

# my_fun(3,4,"jedf",9)

data = {"id":[1,3,4,22], "name":("ansari","abc"),"city":"blore", "idone":101}

mylist = [{"id":101, "name":"ansari","city":"blore", "idone":101},{"id":104, "name":"ansari","city":"hyd", "idone":101}]

for i,k in data.items():
    print(i,k)