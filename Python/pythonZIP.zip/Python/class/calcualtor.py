#abstract class
from abc import ABC,abstractmethod 

class LTTS(ABC):
    
    @abstractmethod
    def security(self):
        pass
    
    @abstractmethod
    def mask(self):
        pass
    
    def lunch(self):
        print("having lunch")
        
    

class kannad(LTTS):
    
    def security(self):
        print("card Security")
    
    def mask(self):
        pass
    
    def playing(self):
        print("Playing")
    
    def lunch(self):
        print("having lunch")
        

k = kannad()
k.security()