import os
def pwdCheck(password):
    fhP_r=open("pwd.txt", "r")
    s=fhP_r.readline()
    if len(s)>0:
        if (s==str(password)):
            fhP_r.close()
            return 1
        else: 
            fhP_r.close()
            return 0


def pwdChange(password,UpdatedPWD):
    fhP_r=open("pwd.txt", "r")
    fhP_w=open("TEMPpwd.txt", "w")
    s=fhP_r.readline()
    if len(s)>0:
        if (s==str(password)):
            fhP_w.write(str(UpdatedPWD))
            fhP_r.close()
            fhP_w.close()
            os.remove("pwd.txt")
            os.rename("TEMPpwd.txt","pwd.txt")
            return 1
        else: 
            fhP_r.close()
            fhP_w.close()
            os.remove("TEMPpwd.txt")
            return -1
#print(pwdCheck(1111))
print(pwdChange(1234,134))