import pyttsx3

# pre requirements (pip install pyttsx3)(for windows)
# $ sudo pip install pyttsx3 (for linux)

def text_to_speech(*string): # text to speech function
    engine = pyttsx3.init()
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)
    engine.say(string)
    engine.runAndWait()

choice = "Elephant This is a four legged animal which weighs around one ton"
text_to_speech(choice)