# for multi filing

def addNumbers(a,b):
    return a+b

def subNumbers(a,b):
    return a-b

def mulNumbers(a,b,c):
    return a*b*c

def divNumbers(a,b):
    return a/b