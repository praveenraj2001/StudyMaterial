# import packageDay2

# print(packageDay2.addNumbers(1,2))


# OR


# import packageDay2 as pkg

# print(pkg.addNumbers(1,2))



# Only Specific
# from packageDay2 import addNumbers,subNumbers
# print(addNumbers(1,2))
# print(subNumbers(1,2))



# To get all the functions we use
# from packageDay2 import *
# print(subNumbers(1,2))




#package will solve name conflicts
from pack1.packageDay2 import *
print(subNumbers(1,2))