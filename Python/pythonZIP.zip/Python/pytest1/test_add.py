import pytest
from add import adds,subs,mul,div
# from pytest1.add import validate_age

def test_add():
    assert adds(10,20) == 30
    
def test_add1():
    assert adds(5,5) == 10
    
def test_add2():
    assert adds(-5,5) == 0
    
def test_add3():
    assert adds(-5,-5) == -10
# py -m pytest test_add.py  --> for running


def test_sub():
    assert subs(10,20) == -10
    
def test_sub1():
    assert subs(5,5) == 0
    
def test_sub2():
    assert subs(-5,5) == -10
    
def test_sub3():
    assert subs(-5,-5) == 0


def test_mul():
    assert mul(10,20) == 200
    
def test_mul1():
    assert mul(5,5) == 25
    
def test_mul2():
    assert mul(-5,5) == -25
    
def test_mul3():
    assert mul(-5,-5) == 25


def test_div():
    assert div(0,20) == 0
    
def test_div1():
    assert div(5,5) == 1
    
def test_div2():
    assert div(-5,5) == -1
    
def test_div3():
    assert div(-5,0) == 1
    
# def test_validate-age_msg():
#     with pytest.raises(ValueError) as info:
#         validate_age(11)
#     assert str(info.value) == "you r less than 18 -- cannot vote"