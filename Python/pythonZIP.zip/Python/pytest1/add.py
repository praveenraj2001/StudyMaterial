def adds(a,b):
    return a+b

def subs(a,b):
    return a-b

def mul(a,b):
    return a*b

def div(a,b):
    return a/b

def validate_age(age):
    raise 