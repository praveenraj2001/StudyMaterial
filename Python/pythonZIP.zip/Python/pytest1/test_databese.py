import pytest

#python fixture

def database_details():
    name = "ansari"
    phone = 9494949494
    age = 20
    return [name,phone,age]
    
    
def test_checkname(database_details):
    myname = "ansari"
    assert database_details[0]==myname