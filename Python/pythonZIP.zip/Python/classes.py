from fileinput import filename
import os
import pyttsx3

filename = "History_record.txt"


class clsUpdate():
    def updateData(self, filename, id, information):
        fh_r = open(filename, "r")
        fh_w = open("temp.txt", "w")
        s = ' '
        cnt = False
        while(s):
            s = fh_r.readline()
            L = s.split("-")
            if len(s) > 0:
                if int(L[0]) == id:
                    fh_w.write(L[0]+"-"+L[1]+"-"+L[2]+"-"+information+"\n")
                    cnt = True
                else:
                    fh_w.write(s)
        if cnt is False:
            fh_w.close()
            fh_r.close()
            os.remove(filename)
            os.rename("temp.txt", filename)
            return -1
        else:
            fh_w.close()
            fh_r.close()
            os.remove(filename)
            os.rename("temp.txt", filename)
            return 0


class clsDelete():
    def deleteData(self,filename, id):
        fh_r = open(filename, "r")
        fh_w = open("temp.txt", "w")
        s = ' '
        while(s):
            s = fh_r.readline()
            L = s.split("-")
            if len(s) > 0:
                if int(L[0]) == id:
                    fh_w.write("")
                else:
                    fh_w.write(s)
        fh_w.close()
        fh_r.close()
        os.remove(filename)
        os.rename("temp.txt", filename)


class clsInsert():
    def insertData(self,filename, id):

        fh_r = open(filename, "r")
        fh_w = open("temp.txt", "w")
        s = ' '
        cnt = True
        while(s):
            s = fh_r.readline()
            L = s.split("-")
            if len(s) > 0:
                fh_w.write(L[0]+"-"+L[1]+"-"+L[2]+"-"+L[3])
                if int(L[0]) == id:
                    print("ID already existing please change the ID")
                    cnt = False
        if(cnt):
            name_type = input("Please Enter Type of entry ")
            name = input("Please enter name of entry ")
            information = input("Please Enter information of entry ")
            fh_w.write("\n"+str(id)+"-"+name_type+"-"+name+"-"+information+"\n")
            fh_w.close()
            fh_r.close()
            os.remove(filename)
            os.rename("temp.txt", filename)
            return
        fh_w.close()
        fh_r.close()
        os.remove("temp.txt")


class Admin(clsUpdate, clsDelete, clsInsert):

    def text_to_speech(self, *string):  # text to speech function
        engine = pyttsx3.init()
        voices = engine.getProperty('voices')
        engine.setProperty('voice', voices[1].id)
        engine.say(string)
        engine.runAndWait()

    def pwdCheck(self, password):
        fhP_r = open("pwd.txt", "r")
        s = fhP_r.readline()
        if len(s) > 0:
            if (s == str(password)):
                fhP_r.close()
                return 1
            else:
                fhP_r.close()
                return 0

    def pwdChange(self, password, UpdatedPWD):
        fhP_r = open("pwd.txt", "r")
        fhP_w = open("TEMPpwd.txt", "w")
        s = fhP_r.readline()
        if len(s) > 0:
            if (s == str(password)):
                fhP_w.write(str(UpdatedPWD))
                fhP_r.close()
                fhP_w.close()
                os.remove("pwd.txt")
                os.rename("TEMPpwd.txt", "pwd.txt")
                return 1
            else:
                fhP_r.close()
                fhP_w.close()
                os.remove("TEMPpwd.txt")
                return -1

# deleteData("History_record.txt",3)
# insertData("History_record.txt",2,"Pre Historic animal","Dianosour","noice information")
# insertData("History_record.txt",3)


obj = Admin()
# print(obj.pwdCheck(1234))


#obj.text_to_speech("Welcome to Global International Museum")
#obj.text_to_speech("Type ADMIN for admin mode or Type tourist for tourist mode")
userChoice = input("Please select The mode ADMIN / TOURIST --> ")
if(userChoice.lower() == "admin"):
    pwd = input("Please Enter the Password for ADMIN --> ")
    if(obj.pwdCheck(pwd)):

        print("Hello Please choose one of the following options")
        print("Press 1 to update data record")
        print("Press 2 to delete data record")
        print("Press 3 to insert new data record")
        print("Press 4 to Update Password")
        print("Press 5 to exit ADMIN MODE")
        option = int(input())
        if(option == 1):
            id = int(input("Please enter ID of the antique --> "))
            if(obj.updateData(filename, id, "0") == 0):
                info = input(f"Please enter Information for {id} --> ")
                obj.updateData(filename, id, info)
            else:
                print("You have entered Wrong ID ")

        elif(option==2):
            id = int(input("Please enter ID of the antique that needs to be deleted --> "))
            obj.deleteData(filename,id)
        elif(option==3):
            id = int(input("Please enter ID of new antique that needs to be added --> "))
            obj.insertData(filename,id)
        elif(option==4):
            oldPwd = int(input("Please Enter the OLD Password --> "))
            newPwd = int(input("Please Enter the NEW Password --> "))
            if(obj.pwdChange(oldPwd,newPwd)==1):
                print("Password has successfully changed ")
            else:
                print("You have entered Wrong OLD Password please re enter the password")
        else:
            exit
    else:
        print("You have entered wrong password Please choose Mode again")
elif userChoice.lower() == "tourist":
    print("tourist is chosen")
