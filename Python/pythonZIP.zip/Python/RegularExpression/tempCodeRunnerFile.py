
# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.findall("\d",data)
# print(res) # This find all elements and gives a list as return
