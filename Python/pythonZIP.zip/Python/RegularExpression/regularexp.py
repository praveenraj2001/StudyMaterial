# Regular expression is a special sequence of characters that uses a search pattern to find a string or set of strings
# python provides a re module for regular expression

# search,findall,match,  split,sub 

from ast import pattern
import re



# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.search("age",data)

# if(res):
#     print("Match Found")
# else:
#     print("Match is not found")



# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.search("and",data)
# print(res) # only finds first and



# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.findall("and",data)
# print(res) # This find all elements and gives a list as return



# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.match("and",data)
# print(res) # This find all elements and gives a list as return



# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.split("and",data)
# print(res) # This find all elements and gives a list as return




# # use "\s" insted of " "

# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.sub("\s","--",data)
# print(res) # This find all elements and gives a list as return



# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.sub("\s","--",data,5) # replace for only first 5 spaces
# print(res) # This find all elements and gives a list as return


# characters from A-Z
# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# pattern = "[A-Z]"
# res = re.findall(pattern,data)
# print(res) # This find all elements and gives a list as return


# characters from A-Z and a-m
# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# pattern = "[A-Za-m]"
# res = re.findall(pattern,data)
# print(res) # This find all elements and gives a list as return



# data0 = "welcome \noon my world"
# data1 = "welcome \\noon my world"
# data2 = r"welcome \noon my world"

# print(data0)
# print(data1)
# print(data2)


# data = r"Welcome \noon My world"
# comp = re.compile("[A-Z]") # this is pre compile (for Time Saving)
# res = re.findall(comp,data)

# print(res)

# data = """
# Hello world
# welcome to my world
# how are you
# """
# comp = re.compile("\n") # this is pre compile (for Time Saving)
# res = comp.sub(" ",data)

# print(res)




# \d will print all numeric values in string
# \D will give all non numberi values


# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.findall("\d",data)
# print(res) # This find all elements and gives a list as return


# \w will give special characters
# \w will give all except special characters

# \S will give all the characters without spaces


# starting and ending with certain characters
# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.findall("an\B",data) # starts with an
# print(res) # This find all elements and gives a list as return


# res1 = re.findall("\Bnd",data) # ends with nd
# print(res1) # This find all elements and gives a list as return


# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.findall("an{1}",data) # starts with an
# print(res) # This find all elements and gives a list as return



# data = "My name is Amsari and I am from Bangalore and My age is 40 and I draw $2000"

# res = re.findall("an..",data) # starts with an
# print(res) # This find all elements and gives a list as return
